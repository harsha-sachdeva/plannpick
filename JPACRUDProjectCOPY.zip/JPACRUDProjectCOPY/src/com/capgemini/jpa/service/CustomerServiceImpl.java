package com.capgemini.jpa.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.jpa.dao.CustomerDaoImpl;
import com.capgemini.jpa.dao.ICustomerDAO;
import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.CustomerException;
import com.capgemini.jpa.exception.InvalidBalance;
import com.capgemini.jpa.exception.LowBalance;

public class CustomerServiceImpl implements ICustomerService {
	private ICustomerDAO employeeDAO=new CustomerDaoImpl();

	@Override
	public Integer addNewCustomer(Customer employee) throws CustomerException, InvalidBalance {
		return employeeDAO.addNewCustomer(employee);
		
	}

	@Override
	public Customer showCustomer(Integer accno, Integer pin) throws CustomerException {
		// TODO Auto-generated method stub
		return employeeDAO.showCustomer(accno, pin);
	}



	@Override
	public Customer depositCustomer(Integer accno, Double dep) throws CustomerException {
		// TODO Auto-generated method stub
		return employeeDAO.depositCustomer(accno, dep);
	}

	@Override
	public Customer withdrawCustomer(Integer accno, Double withdraw, Integer pin)
			throws CustomerException, LowBalance {
		// TODO Auto-generated method stub
		return employeeDAO.withdrawCustomer(accno, withdraw, pin);

	}

	@Override
	public Customer fundTransfer(Integer from, Integer to, Double transfer) throws CustomerException {
		// TODO Auto-generated method stub
		return employeeDAO.fundTransfer(from, to, transfer);
	}

	

	@Override
	public List<Transaction> printTransactions(int accountNumber)
			throws CustomerException {
		return employeeDAO.printTransactions(accountNumber);
	}

	
	

	public boolean validateName(String name) {
		boolean a;
		String regx = "[a-zA-Z]{2,20}+";
	    Pattern pattern = Pattern.compile(regx,Pattern.CASE_INSENSITIVE);
	    Matcher matcher = pattern.matcher(name);
	    a =  matcher.find();
	    if(a==false)
	    {
	    	System.out.println("Enter correct name");
	    	return false;
	    }
	    else 
	    	return true;
	}
	
	
	public boolean isValidEmailAddress(String email) {
        String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
        java.util.regex.Matcher m = p.matcher(email);
        return m.matches();
 }
	
	public boolean validateNumber(String mobile)
	{
		
		if (mobile.matches("[0-9]{10}")) {
			 return true; 
			
		}
		else System.out.println("Enter valid mobile number");
		return false;
	}
	
	public boolean govtid(String id)
	{
		
		if (id.matches("[0-9]{5}")) {
			 return true; 
			
		}
		else System.out.println("invalid id number");
		return false;
	}

	public boolean validateAmount(Double balance) {
		// TODO Auto-generated method stub
		if( balance>0)
			
		return true; 
		else{System.out.println("Enter correct amount");
		return false;
		}
	}
	
	
	
	
	
	
	
}
