package com.capgemini.jpa.exception;

public class InvalidBalance extends Exception{
	private String status;
	
	public InvalidBalance() {
		System.out.println("Invalid Amount");
	}
	
	
	
	
}
