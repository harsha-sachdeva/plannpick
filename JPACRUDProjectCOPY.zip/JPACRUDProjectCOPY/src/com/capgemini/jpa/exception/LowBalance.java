package com.capgemini.jpa.exception;

public class LowBalance extends Exception{
	
	public LowBalance()
	{
		System.out.println("Low Balance");
	}

}
