package com.capgemini.jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.CustomerException;
import com.capgemini.jpa.exception.InvalidBalance;
import com.capgemini.jpa.exception.LowBalance;
import com.capgemini.jpa.utility.JPAUtil;

public class CustomerDaoImpl implements ICustomerDAO {
	private EntityManager entityManager= null;

	@Override
	public Integer addNewCustomer(Customer b) throws CustomerException, InvalidBalance {

		try{
			entityManager=JPAUtil.getEntityManager();
			
			entityManager.getTransaction().begin();
			
			
			Transaction trans = new Transaction();
			trans.setBankAccount(b);
			
			if(b.getBalance()==null)
				throw new InvalidBalance();
			trans.setTransactionAmount(b.getBalance());
			trans.setTransactionType("Deposited");
			entityManager.persist(trans);
			
			
			entityManager.persist(b); //add in table
			entityManager.getTransaction().commit();	
			
		}catch(PersistenceException e) {
			e.printStackTrace();
			
			throw new CustomerException(e.getMessage());
		}catch(InvalidBalance e)
		{
			
		}
		finally {
			entityManager.close();
		}
		return b.getAccno();
		
		
		
	}

	@Override
	public Customer showCustomer(Integer accno, Integer pin) throws CustomerException {
		Customer customer=null;
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			customer = entityManager.find(Customer.class, accno);
			
			if(customer==null)
				throw new CustomerException("not found");
			
			if(customer.getAccno().equals(accno) && customer.getPin().equals(pin))
			{
				return customer;
				
			}
			
			entityManager.getTransaction().commit();			
		}catch(IllegalArgumentException e)
		{
			System.out.println("Enter correct details"/*"Illegal Argument Exception"*/);
		}
		catch(PersistenceException e) {
			System.out.println(".");
			//TODO: Log to file
			throw new CustomerException(e.getMessage());
		}catch(CustomerException e)
		{
			System.out.println("customer not found");
		}
		finally {
			entityManager.close();
		}
		return customer;
		
		

	}







	@Override
	public Customer depositCustomer(Integer accno, Double dep) throws CustomerException {
		// TODO Auto-generated method stub
		Customer customer= null;
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			customer= entityManager.find(Customer.class, accno);
			if (customer==null)
				throw new CustomerException();
			//System.out.println(accno + "---" + "----" + employee);
			//Employee b = entityManager.find(Employee.class,accno);
			Double present = customer.getBalance();
			present += dep; 
			customer.setBalance(present);
			entityManager.merge(customer);
			Transaction trans = new Transaction();
			trans.setTransactionAmount(dep);
			trans.setTransactionType("Deposited");
			trans.setBankAccount(customer);
			entityManager.persist(trans);
	
			entityManager.getTransaction().commit();	

			//System.out.println("Account Balance is: " + employee.getBalance());



		}
		catch(IllegalArgumentException e)
		{
			System.out.println("Enter correct details"/*"Illegal Argument Exception"*/);
		}
		catch(PersistenceException e) {
			throw new CustomerException(e.getMessage());
			
			
		}catch(CustomerException e)
		{
			System.out.println("customer not found");
		}
		finally {
			entityManager.close();
		}
		return customer;
		

	}

	@Override
	public Customer withdrawCustomer(Integer accno, Double withdraw ,Integer pin)
			throws CustomerException, LowBalance {
		Customer customer = null;
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			customer= entityManager.find(Customer.class, accno);
			if (customer==null)
				throw new CustomerException();
			
			//System.out.println(accno);
			//System.out.println(employee.getAccno());
			//if(employee.getAccno() == accno && employee.getPin() == pin)
			//{
				Double present = customer.getBalance();
			present -= withdraw; 
			if(present > 0)
			
			customer.setBalance(present);
			else
				throw new LowBalance();
			
			Transaction trans = new Transaction();
			trans.setTransactionAmount(withdraw);
			trans.setTransactionType("Withdrawn");
			trans.setBankAccount(customer);
			entityManager.persist(trans);
			
			entityManager.merge(customer);
			entityManager.getTransaction().commit();	



		}catch(IllegalArgumentException e)
		{
			System.out.println("Enter correct details");
		}
		catch(PersistenceException e) {
			throw new CustomerException(e.getMessage());
			
			
		}catch(CustomerException e)
		{
			System.out.println("customer not found");
		}finally {
			entityManager.close();
		}
		return customer;
		
		

	}

	@Override
	public Customer fundTransfer(Integer from, Integer to, Double transfer) throws CustomerException {
		Customer employee_from = null;
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			
			employee_from = entityManager.find(Customer.class, from);
			Customer employee_to = entityManager.find(Customer.class, to);
			if(employee_from==null)
				throw new CustomerException();
			if(employee_to==null)
				throw new CustomerException();
			
			
			Double present_from = employee_from.getBalance();
			Double present_to = employee_to.getBalance();
			
			present_from -= transfer;
			present_to += transfer;
			employee_from.setBalance(present_from);
			employee_to.setBalance(present_to);
			
			//FROM
			Transaction trans_from = new Transaction();
			trans_from.setTransactionAmount(transfer);
			trans_from.setTransactionType("Fund Transfer(Sent)");
			trans_from.setBankAccount(employee_from);
			entityManager.persist(trans_from);
			
			//TO
			Transaction trans_to = new Transaction();
			trans_to.setTransactionAmount(transfer);
			trans_to.setTransactionType("Fund Transfer(Recieved)");
			trans_to.setBankAccount(employee_to);
			entityManager.persist(trans_to);
			
			
			entityManager.merge(employee_from);
			entityManager.merge(employee_to);
			
			entityManager.getTransaction().commit();	

			System.out.println("Account Balance(FROM) is: " + employee_from.getBalance());
			System.out.println("Account Balance(TO) is: " + employee_to.getBalance());



		}catch(IllegalArgumentException e)
		{
			System.out.println("Enter correct details");
		}
		catch(PersistenceException e) {
			e.printStackTrace();
			
			throw new CustomerException(e.getMessage());
		}finally {
			entityManager.close();
		}
		return employee_from;
		
		
	}

	

	@Override
	public List<Transaction> printTransactions(int accountNumber)
			throws CustomerException {
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
	    Query query=entityManager.createNativeQuery("select*from bank_tranaction where account_Number=?",Transaction.class);
		query.setParameter(1,accountNumber);
		
	    List<Transaction> transList = query.getResultList();
	    System.out.println(transList);
	    return transList;
		}catch(PersistenceException e) {
			e.printStackTrace();
			

			throw new CustomerException(e.getMessage());
		}finally {
			entityManager.close();
			
		}
	}

}
