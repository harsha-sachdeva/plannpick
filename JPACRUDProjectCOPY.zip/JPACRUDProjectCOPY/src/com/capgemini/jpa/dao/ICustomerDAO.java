package com.capgemini.jpa.dao;

import java.util.List;

import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.CustomerException;
import com.capgemini.jpa.exception.InvalidBalance;
import com.capgemini.jpa.exception.LowBalance;

public interface ICustomerDAO {
	public abstract Integer addNewCustomer(Customer employee) throws CustomerException, InvalidBalance;
	public abstract Customer showCustomer(Integer accno, Integer pin) throws CustomerException;
	public abstract Customer depositCustomer(Integer accno, Double dep) throws CustomerException;
	public abstract Customer withdrawCustomer(Integer accno, Double withdraw , Integer pin) throws CustomerException, LowBalance;
	public abstract Customer fundTransfer(Integer from, Integer to, Double transfer) throws CustomerException;
	 public List<Transaction> printTransactions(int accountNumber) throws CustomerException;//
	
}
