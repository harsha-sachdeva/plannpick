package com.capgemini.jpa.entity;



import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

@Entity
@NamedQueries({
		@NamedQuery(name="q1",query="select e from Employee e"),
		@NamedQuery(name="q2",query="select e from Employee e where e.balance>45000.00")
		}
		)
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	//private Integer empid;
	@Column(name="name", length=30, nullable=false)
	private String name;
	@NotNull
	
	private Double balance;
	private Integer account_no;
	private Integer pin;
		
	public Employee() {
		
	}

	public String getEname() {
		return name;
	}

	public Double getBalance() {
		return balance;
	}

	public Integer getAccount_no() {
		return account_no;
	}

	public Integer getPin() {
		return pin;
	}

	public void setEname(String name) {
		this.name = name;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public void setAccount_no(Integer account_no) {
		this.account_no = account_no;
	}

	public void setPin(Integer pin) {
		this.pin = pin;
	}

	public Employee(String name, Double balance, Integer account_no,
			Integer pin) {
		super();
		this.name = name;
		this.balance = balance;
		this.account_no = account_no;
		this.pin = pin;
	}

	

	
	
	

	
	
	
	
	
	
}
