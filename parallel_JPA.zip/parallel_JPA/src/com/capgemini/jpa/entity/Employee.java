package com.capgemini.jpa.entity;



import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

@Entity
@NamedQueries({
		@NamedQuery(name="q1",query="select e from Employee e"),
		@NamedQuery(name="q2",query="select e from Employee e where e.salary>45000.00")
		}
		)
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long accountNo;
	@Column(name="name", length=30, nullable=false)
	private String name;
	@NotNull
	private String id;
	private Integer age;
	private String mobileNo;
	private String emailId;
	private String addr;
	private Integer pin;
	private Double balance;
	
	public Employee() {
		
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Employee [accountNo=" + accountNo + ", name=" + name + ", id=" + id + ", age=" + age + ", mobileNo="
				+ mobileNo + ", emailId=" + emailId + ", addr=" + addr + ", pin=" + pin + ", balance=" + balance + "]";
	}

	public Employee(long accountNo, String name, String id, int age, String mobileNo, String emailId, String addr,
			int pin, double balance) {
		super();
		this.accountNo = accountNo;
		this.name = name;
		this.id = id;
		this.age = age;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.addr = addr;
		this.pin = pin;
		this.balance = balance;
	}

	

	
	
	
	
	
	
}
