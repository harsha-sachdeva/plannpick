package com.capg.cms.ui;

import static org.junit.Assert.fail;

import org.junit.Test;

import com.capg.cms.beans.Customer;
import com.capg.cms.dao.ICustomerDAO;

public class ClientTest {

	static ICustomerDAO cust=null;
	
	/*@Test
	public void test() {
		fail("Not yet implemented");
	}*/
	@Test
	public void test() 
	{
		
		Customer cust = new Customer();
		//long acc = cust.getAccountNo();
		
		/*try {
			
			Assert.assertEquals("failure  ",cust.getAccountNo(),cust.getAccountNo());
		} catch (CustomerNotFound | NullPointerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		
	}
	
	
	
	
	
	
	/*@Test
	public void test() {
		fail("Not yet implemented");
	}*/

}
