package com.capg.cms.dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;

import org.junit.Test;

import com.capg.cms.beans.Customer;

public class CustomerDAOImpTest {

	@Test
	public void testAddCustomer() /*throws NullPointerException*/{
		Customer c1 = new Customer();
		Customer c2 = new Customer();
		
		//assertNotNull(c);
		assertSame("hiii", c1, c2);
	
		//asse
		//fail("Not yet implemented");
	}

	@Test
	public void testDisplayCustomer() {
		//fail("Not yet implemented");
		
	}

	@Test
	public void testDeposit() {
		//fail("Not yet implemented");
	}

	@Test
	public void testWithdraw() {
		//fail("Not yet implemented");
	}

	@Test
	public void testFundTransfer() {
		//fail("Not yet implemented");
	}

	@Test
	public void testPrintTransactions() {
		//fail("Not yet implemented");
	}

	@Test
	public void testPrintTrns() {
		//fail("Not yet implemented");
	}

}
